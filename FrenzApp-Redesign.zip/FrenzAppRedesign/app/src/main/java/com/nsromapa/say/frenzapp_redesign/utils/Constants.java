package com.nsromapa.say.frenzapp_redesign.utils;

public class Constants {
    public static final String NEWS_FEEDS = "http://192.168.8.101/frenzapp/posts";
}
